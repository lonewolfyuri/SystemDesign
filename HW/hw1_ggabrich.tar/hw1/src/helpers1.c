// Define all helper functions for hw1 in this file

#include "stdio.h"
#include "helpers1.h"
// Simple helper function that counts all symbols in stdin.
// If edit == 1, all symbold are removed and the rest is 
// output to stderr.
// Symbols are defined as ASCII [0x21-0x7E], except [A-Z,a-z,0-9].
int countSymbols(int edit) {
        int result = 0;
        char cur;
	cur = getchar();
	if (cur == -1) {
       		return -128;
 	}
        while (cur != -1) {
		if (isascii(cur) == 0) {
                        return result*-1;
                } else if ((cur >= 0x21) && (cur <= 0x7E)) {
                        if (cur < 48) {
                                result++;
                        } else if (cur < 58) {
                                if (edit == 1) {
                                        fputc(cur, stderr);
                                }
                        } else if (cur < 65) {
                                result++;
                        } else if (cur < 91) {
                                if (edit == 1 ) {
                                        fputc(cur, stderr);
                                }
                        } else if (cur < 97) {
                                result++;
                        } else if (cur < 123) {
                                if (edit == 1) {
                                        fputc(cur, stderr);
                                }
                        } else if (cur < 127) {
                                result++;
                        } else {
                                if (edit == 1) {
                                        fputc(cur, stderr);
                                }
                        }                       
                } else if (edit == 1) {
                        fputc(cur, stderr);
                }
        cur = getchar();
	}
        
        return result;  
}

// Simple helper function that counts all numbers in stdin.
// If edit == 1, all numbers are removed and the rest is 
// output to stderr.
// Numbers are ASCII [0x30-0x39].
// wasDig = 0 if it was not digit before, 1 if it was
int countNumbers(int edit) {
	int result = 0, wasDig = 0;
	char cur;
	cur = getchar();
	if (cur == -1) {
                return -128;
        }
	while (cur != -1) {
                if (isascii(cur) == 0) {
                        return result*-1;
		} else if ((cur >= 0x30) && (cur <= 0x39)) {
			if (wasDig == 0) {
				result++;
				wasDig = 1;
			}
		} else { 
			if (edit == 1) {
				fputc(cur, stderr);
			}
			wasDig = 0;
		}
	cur = getchar();
	}

	return result; 
}   

// Simple helper function that counts number of lines with
// leading whitespace in stdin. (' ', '\t', '\r', '\v', '\f').
// If edit == 1, all leading whitespace is removed from each line
// and the rest is output to stderr.
// Line: -1 = old line/not only whitespace, 0 = new line/only whitespace, 1 = lead in new line 
int countLines(int edit) {
	int result = 0, line = 1;
	char cur;
	cur = getchar();
	if (cur == -1) {
                return -128;
        }
	while (cur != -1) {
                if (isascii(cur) == 0) {
                        return result*-1;
		}
		switch(cur) {
			case '\t':
				if (line == 1) {
					line = 0;
					result++;
				} else if (line == -1) {
					if (edit == 1) {
                                                fputc(cur, stderr);                                             }
				}
				break;
			case '\n':
				line = 1;
				if (edit == 1) {
					fputc(cur, stderr);
				}
				break;
			case '\v':
				if (line == 1) {
                                        line = 0;
                                        result++;
                                } else if (line == -1) {
                            		if (edit == 1) {
						fputc(cur, stderr);
                                	}
				}
				break;
			case '\f':
				if (line == 1) {
                                        line = 0;
                                        result++;
                                } else if (line == -1) {
                                        if (edit == 1) {
                                                fputc(cur, stderr);                                             }
                                }
				break;
			case '\r':
				if (line == 1) {
                                        line = 0;
                                        result++;
                                } else if (line == -1) {
                                       	if (edit == 1) {
                                                fputc(cur, stderr);                                             }
                                }
				break;
			case ' ':
				if (line == 1) {
                                        line = 0;
                                        result++;
                                } else if (line == -1) {
                                        if (edit == 1) {
                                       		fputc(cur, stderr);                                		}
                                }
				break;
			default:
				line = -1;
				if (edit == 1) {
					fputc(cur, stderr);
				}
		}
	cur = getchar();
	}

	return result;
}

// Simple helper function that counts all occurances of tab ('\t')
// and expands the tab into num # of spaces. 
// Outputs result to stderr.
int expandTab(int num) {
	int result = 0, ndx;
        char cur;
	cur = getchar();
        if (cur == -1) {
                return -128;
        }
	while (cur != -1) {        
                if (isascii(cur) == 0) {
                        return result*-1;
		} else if (cur == 9) {
                        result++;
			for (ndx = 0; ndx < num; ndx++) {
				fputc(' ', stderr);
                	}
		} else {
                        fputc(cur, stderr);
                }
        cur = getchar();
	}

        return result;
}

// Simple helper function that counts all occurances of num # of
// consecutive spaces (' ') and contracts them into a tab ('\t').
// Outputs result to stderr.
int contractTab(int num) {
	int result = 0, ndx = 0;
        char cur;
	cur = getchar();
        if (cur == -1) {
                return -128;
        }
	while (cur != -1) {
                if (isascii(cur) == 0) {
                        return result*-1;
                } else if (cur == 32) {
			if (++ndx == num) {
				fputc('\t', stderr);
                        	result++;
				ndx = 0;
			}
                } else if (ndx > 0) {
			for (ndx; ndx > 0; ndx--) {
				fputc(' ', stderr);
			}
			fputc(cur, stderr);
		} else {
			ndx = 0;
                        fputc(cur, stderr);
                }
        cur = getchar();
	}

        return result;
}
   
