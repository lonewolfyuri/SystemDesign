// George Gabricht
// ggabrich


#include "hw1.h"
// You may define any helper functions you want. Place them in helpers.c/.h


// main program
int main (int argc, char *argv[])
{
	int result, num, edit = 0;	

	if (argc == 2) {
		if (strcmp(argv[1], "-S") == 0) {
				result = countSymbols(edit);
		} else if (strcmp(argv[1],"-N") == 0) {
				result = countNumbers(edit);
		} else if (strcmp(argv[1], "-L") == 0) {
				result = countLines(edit);
		} else {
			return 1;
		}
	} else if (argc == 3) {
		if (strcmp(argv[1], "-S") == 0) {
			if (strcmp(argv[2], "-O") == 0) {
				edit = 1;
			} else {
				return 1;
			}
                        result = countSymbols(edit);
		} else if (strcmp(argv[1], "-N") == 0) {
			if (strcmp(argv[2], "-O") == 0) {
				edit = 1;
			} else {
				return 1;
			}
                        result = countNumbers(edit);
          	} else if (strcmp(argv[1], "-L") == 0) {
			if (strcmp(argv[2], "-O") == 0) {
                               	edit = 1;
                      	} else {
                      		return 1;
                    	}
                        result = countLines(edit);
           	} else if (strcmp(argv[1], "-E") == 0) {
			num = atoi(argv[2]);
			if (num == 0) {
				return 1;
			} else {
				result = expandTab(num);
			}
		} else if (strcmp(argv[1], "-C") == 0) {
			num = atoi(argv[2]);
			if (num == 0) {
				return 1;
			} else {
				result = contractTab(num);
			}
		} else {
                      	return 1;
              	}	
	} else if (argc == 4) {
		if (strcmp(argv[1], "-E") == 0) {
                      	num = atoi(argv[2]);
                      	if (num == 0) {
                          	return 1;
                     	} else if (strcmp(argv[3], "-O") != 0) {
					return 1;
			}
                    	result = expandTab(num);
           	} else if (strcmp(argv[1], "-C") == 0) {
                   	num = atoi(argv[2]);
                   	if (num == 0) {
                            	return 1;
                    	} else if (strcmp(argv[3], "-O") != 0) {
				return 1;
                     	}
                        result = contractTab(num);
          	} else {
                	return 1;
           	}
	} else {
		return 1;
	}
	
	if (result < 0) {
		if (result != -128) {
			result = result*-1;
			printf("%d\n", result);		
		}
		return 1;
	}
	printf("%d\n", result);	
	return 0;
}
