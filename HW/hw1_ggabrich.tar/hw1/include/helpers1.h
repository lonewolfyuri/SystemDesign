#ifndef HELPERS1
#define HELPERS1

// Declare all helper functions for hw1 in this file
//
//

// Simple helper function that counts all symbols in stdin.
// If edit == 1, all symbold are removed and the rest is 
// output to stderr.
// Symbols are defined as ASCII [0x21-0x7E], except [A-Z,a-z,0-9].
int countSymbols(int edit);

// Simple helper function that counts all numbers in stdin.
// If edit == 1, all numbers are removed and the rest is 
// output to stderr.
// Numbers are ASCII [0x30-0x39].
int countNumbers(int edit);

// Simple helper function that counts number of lines with
// leading whitespace in stdin. (' ', '\t', '\r', '\v', '\f').
// If edit == 1, all leading whitespace is removed from each line
// and the rest is output to stderr.
int countLines(int edit);

// Simple helper function that counts all occurances of tab ('\t')
// and expands the tab into num # of spaces. 
// Outputs result to stderr.
int expandTab(int num);

// Simple helper function that counts all occurances of num # of
// consecutive spaces (' ') and contracts them into a tab ('\t').
// Outputs result to stderr.
int contractTab(int num);

#endif
