// NAME
// netid

#include "morsecode.h"
#include "hw2.h"

char* MorseCode[] = {MorseExclamation, MorseDblQoute, MorseHashtag, Morse$, MorsePercent, MorseAmp, MorseSglQoute, MorseOParen, MorseCParen, MorseStar, MorsePlus, MorseComma, MorseDash, MorsePeriod, MorseFSlash, Morse0, Morse1, Morse2, Morse3, Morse4, Morse5, Morse6, Morse7, Morse8, Morse9, MorseColon, MorseSemiColon, MorseLT, MorseEQ, MorseGT, MorseQuestion, MorseAt, MorseA, MorseB, MorseC, MorseD, MorseE, MorseF, MorseG, MorseH, MorseI, MorseJ, MorseK, MorseL, MorseM, MorseN, MorseO, MorseP, MorseQ, MorseR, MorseS, MorseT, MorseU, MorseV, MorseW, MorseX, MorseY, MorseZ};

/* Part 1 Functions */
int toMorse(FILE *instream, char **mcmsg_ptr){
        // Insert code here
        return 0;
}

void createKey(char* keyphrase, char* key){
    // Insert code here
}

char morseToKey(char* mcmsg, char* key){
    char* FMCarray = ".....-..x.-..--.-x.x..x-.xx-..-.--.x--.-----x-x.-x--xxx..x.-x.xx-.x--x-xxx.xx-";
        // Insert code here
        return 0;
}

int FMCEncrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
        return 0;
}

/* Part 2 Functions */
int fromMorse(char *mcmsg, FILE* outstream){
        // Insert code here
        return 0;
}

int FMCDecrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
        return 0;
}

