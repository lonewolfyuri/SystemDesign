// Your name
// Netid


// Header file for hw1.c

#include<stdio.h>
#include<stdlib.h>
#include"helpers1.h"
