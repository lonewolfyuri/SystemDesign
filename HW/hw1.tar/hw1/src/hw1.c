// Your name
// Netid


#include "hw1.h"
// You may define any helper functions you want. Place them in helpers.c/.h


// main program
int main (int argc, char *argv[])
{

	//Insert your hw1 code here 

	return 0;
}
