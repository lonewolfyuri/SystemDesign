// Define all helper functionp ndxs for hw1 in this file

// given a character * cur, converts a lowercase to 
// uppercase, otherwise does nothing. Returns ptr to new char.
char* toUpper(char * cur) {
	if ((*cur > 96) && (*cur < 123)) {
		*cur = *cur - 32;
	}
	return cur;
}

int strcomp2(char *msg, char **morseTable, int len) {
        int ndx;
        for (ndx = 0; ndx < len; ndx++) {
                if (*(msg + ndx) == '\0') {
                        return -1;
                }
        }
        int ndxLen = 0;
        char *tempmsg = msg;

        for (ndx = 0; ndx < 58; ndx++) {
                int ndxLen, result = 1;
                for (ndxLen = 0; ndxLen < len; ndxLen++) {
                        if (*(tempmsg + ndxLen) != *(*(morseTable + ndx) + ndxLen)) {
                                result = 0;
                        }
                }
                if (result == 1) {
                        if (*(*(morseTable + ndx) + len) == '\0') {
				return ndx;
			}
                }
        }
        return -1;
}	

// compares the first three chars of msg to each 
// pattern in fmc - returns index of result or -1 if not found. 
int strcomp(char *msg, char *fmc, int len, int fmcLen) {

	int ndx;
	for (ndx = 0; ndx < len; ndx++) {
		if (*(msg + ndx) == '\0') {
			return -1;
		}
	}
	int ndxLen = 0;
	char *tempmsg = msg, *tempfmc = fmc;

	for (ndx = 0; ndx < fmcLen; ndx++) {
		int ndxLen, result = 1;
		for (ndxLen = 0; ndxLen < len; ndxLen++) {
			if (*(tempmsg + ndxLen) != *(tempfmc + ndxLen)) {
				result = 0;
			}
		}
		if (result == 1) {
			return ndx;
		}
		tempfmc += len;
	}
	return -1;
}

// copies from src to dest until null terminator, and adds an 'x' to end.
// returns number incremets to null terminator in dest after the 'x'.
int strcopy(char *dest,char *src) {
	char *destptr = dest, *srcptr;
	int ndx = 0;
	for (srcptr = src; *srcptr != '\0'; srcptr++) {
		*(destptr++) = *srcptr;
		ndx++;
	}
	*(destptr++) = 'x';
	return ++ndx;
}


int keyToMorse(char *cypher, char *key) {
	char* FMCarray = ".....-..x.-..--.-x.x..x-.xx-..-.--.x--.-----x-x.-x--xxx..x.-x.xx-.x--x-xxx.xx-";
	int ndx;
	char *keyTemp = key, *cypherTemp = cypher;
	for (ndx = 0; ndx < 26; ndx++) {
		if (*cypherTemp == *(keyTemp + ndx)) {
			return (3*ndx);
		}
	}
}					
