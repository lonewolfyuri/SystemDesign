// George Gabricht
// ggabrich - 56735102

#include "morsecode.h"
#include "hw2.h"
#include "helpers2.h"

char* MorseCode[] = {MorseExclamation, MorseDblQoute, MorseHashtag, Morse$, MorsePercent, MorseAmp, MorseSglQoute, MorseOParen, MorseCParen, MorseStar, MorsePlus, MorseComma, MorseDash, MorsePeriod, MorseFSlash, Morse0, Morse1, Morse2, Morse3, Morse4, Morse5, Morse6, Morse7, Morse8, Morse9, MorseColon, MorseSemiColon, MorseLT, MorseEQ, MorseGT, MorseQuestion, MorseAt, MorseA, MorseB, MorseC, MorseD, MorseE, MorseF, MorseG, MorseH, MorseI, MorseJ, MorseK, MorseL, MorseM, MorseN, MorseO, MorseP, MorseQ, MorseR, MorseS, MorseT, MorseU, MorseV, MorseW, MorseX, MorseY, MorseZ};

/* Part 1 Functions */
int toMorse(FILE *instream, char **mcmsg_ptr){
        // Insert code here
	if (instream == NULL) {
		return 2;
	}
	char curChar, blank = '\0';
	int tempNdx, spaceCount = 0, charCount = 0, size = 1000, dblX = 0;
	*mcmsg_ptr = malloc(size*sizeof(char*));	
	if (mcmsg_ptr == NULL) {
		return -1;
	}
	char *temp = *mcmsg_ptr, *result = *mcmsg_ptr;
	for (tempNdx = 0; tempNdx < size; tempNdx++) {
		*(temp++) = '\0';
	}   
	
	for (curChar = getc(instream); curChar != -1; curChar = getc(instream)) {
		if (curChar == -1) {
			break;
		}

		if ((curChar < 0) || (curChar > 127)) {
			strcopy(result, &blank);
			return 0;
		}

		if (curChar == ' ') {
			if (spaceCount++ == 0) {
				dblX = 1;
				result += strcopy(result, &blank);
				charCount++;
			}
		} else {
			spaceCount = 0;
			dblX = 0;
		}

		if (charCount == size-10) {
			size *= 2;
			*mcmsg_ptr = realloc(*mcmsg_ptr, size*sizeof(char*));
			if (mcmsg_ptr == NULL) {
				return -1;
			}
			int ndx = 0;
			for (temp = *mcmsg_ptr; *temp != '\0'; temp++) {
				ndx++;
			}
			for (ndx; ndx < size; ndx++) {
				*(temp++) = '\0';
			}
		}
		curChar = *(toUpper(&curChar)) - 33;
		if ((curChar >= 0) && (curChar < 58)) {
			int inc = strcopy(result, *(MorseCode + curChar));
			result += inc;
			charCount += inc;
		}
	}
	if (dblX == 0) {
		strcopy(result, &blank);
        }
	return 1;
}

void createKey(char* keyphrase, char* key){
    	// Insert code herei
    	char *tempkey = key;
    	if (keyphrase != NULL) {
		char *tempPhrase;
		for (tempPhrase = keyphrase; *tempPhrase != '\0'; tempPhrase++) {
			toUpper(tempPhrase);
			if ((*tempPhrase > 64) && (*tempPhrase < 91)) { 
				int ndx, inside = 0;
				char *temp = key;
				for (ndx = 0; ndx < 26; ndx++) {
					if (*(temp++) == *tempPhrase) {
						inside = 1;
					}	
				}
				if (inside == 0) {
					*(tempkey++) = *tempPhrase;
				}
			} 
		}
	}
	char *alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", *tempalph;
	for (tempalph = alph; *tempalph != '\0'; tempalph++) {
		int ndx, inside = 0;
		char *temp = key;
		for (ndx = 0; ndx < 26; ndx++) {
			if (*tempalph == *(temp++)) {
				inside = 1;	
			}
		}
		if (inside == 0) {
			*(tempkey++) = *tempalph;
		}
	}
}

char morseToKey(char* mcmsg, char* key){
    	char* FMCarray = ".....-..x.-..--.-x.x..x-.xx-..-.--.x--.-----x-x.-x--xxx..x.-x.xx-.x--x-xxx.xx-";
        // Insert code here
        int ndx = strcomp(mcmsg, FMCarray, 3, 26);
	if (ndx == -1) {
		return (char) -1;
	} else {
		int tempNdx;
		char *tempKey = key;
		for (tempNdx = 0; (tempNdx < ndx) && (tempNdx < 26); tempNdx++) {
			tempKey++;
		}	
		return *tempKey;
	}
}

int FMCEncrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
        char *morseResult = NULL;
	int morseInt = toMorse(instream, &morseResult), size = 250, cap = 0, ndx;
	
	char *morseTemp, *result =(char*) malloc(size);
	if (result == NULL) {
		return -1;
	} else {
		for (ndx = 0; ndx < size; ndx++) {
			*result = '\0';
		}
	}
	char *tempResult = result, *new_result;
	for (morseTemp = morseResult; *morseTemp != '\0'; morseTemp++) { 
		if (cap >= 0.8*size) {
			size *= 2;
			new_result = (char*) realloc(result, size);
			if (new_result == NULL) {
				morseInt = -1;
				break;
			} else {
				//free(result);
				result = new_result;
			}
			int ndx = 0;
			char* temp = result;
			for (temp = result; *temp != '\0'; temp++) {
				ndx++;
			}
			for (ndx; ndx < size; ndx++) {
				*(temp++) = '\0';
			}
		}	
		char next = morseToKey(morseTemp, key);
		if (next == -1) {
			morseInt = 0;
			break;
		} else {
			*(tempResult++) = next;
			cap++;
		}
	}
	*tempResult = '\0';
	fprintf(outstream, "%s", result);
	free(result);
	free(morseResult);
	return morseInt;
}

/* Part 2 Functions */
int fromMorse(char *mcmsg, FILE* outstream){
        // Insert code here
	int size = 1000, cap = 0, dblX = 0, ret = 1;
	char* outcome = malloc(size);
	if (outcome == NULL) {
		return -1;
	}
	int ndx;
	char *outNdx = outcome;
	for (ndx = 0; ndx < size; ndx++) {
		*(outNdx++) = '\0';
	}		
        char *msgTemp, *msgTemp2, *new_outcome;
	outNdx = outcome;
	for (msgTemp = mcmsg; *msgTemp != '\0'; msgTemp = msgTemp2 + 1) {
		if (cap >= size*0.8) {
			size *=2;
			new_outcome = realloc(outcome, size);
			if (new_outcome == NULL) {
				ret = -1;
				break;
			} else {
				outcome = new_outcome;
				char *outNdx2 = outNdx;
				ndx = size/2;
				for (ndx = size/2; ndx < size - 1; ndx++) {
					*(outNdx2++) = '\0';
				} 
			}
		}
		int len = 0;
		for (msgTemp2 = msgTemp; *msgTemp2 != 'x'; msgTemp2++) {
			 len++;
		}
		int result = strcomp2(msgTemp, MorseCode, len);
		if (result == -1) {
			ret = 0;
			break;
		} else {
			*(outNdx++) = result + 33;
			cap++;
			// fprintfi(outstream, "%c", (result + 33));
			//fputc(result + 33, outstream);
		}
		if (*(msgTemp2 + 2) == '\0') {
			break;
		}	
		if (*(msgTemp2 + 1) == 'x') {
			*(outNdx++) = ' ';
			cap++;
			//fprintf(outstream, " ");
			//fputc(' ', outstream);
			msgTemp2++;
		}
	}	
	*(outNdx++) = '\0';
	fprintf(outstream, "%s", outcome);
	free(outcome);
	return ret;
}

int FMCDecrypt(FILE *instream, char* key, FILE *outstream){
        // Insert code here
	if (instream == NULL) {
		return 0;
	}
	char* FMCarray = ".....-..x.-..--.-x.x..x-.xx-..-.--.x--.-----x-x.-x--xxx..x.-x.xx-.x--x-xxx.xx-";	
	char curChar;
	int size = 1000, count = 0, intResult = 1;
	char *morseResult = (char*)malloc(size);
	if (morseResult == NULL) {
		return -1;
	} 
	char *curNdx = morseResult, *tempResult;
	for (curChar = getc(instream); curChar != -1; curChar = getc(instream)){
		
		if (count >= size*0.8) {
			size *= 2;
			tempResult = realloc(morseResult, size);
			if (tempResult == NULL) {	
				intResult = -1;
			} else {
				morseResult = tempResult;
			}
		} 

		if ((curChar < 65) || (curChar > 90)) {
			return 0;
		}
		
		int result = keyToMorse(&curChar, key);
		int ndx;
		for (ndx = 0; ndx < 3; ndx++) {
			*(curNdx++) = *(FMCarray + result + ndx);
			count++;
		} 
		
	}
	//*curNdx = '\0';	
	//fprintf(outstream, "%s\n", morseResult);	
	int result = fromMorse(morseResult, outstream);
	free(morseResult); 
        return 1;
}
