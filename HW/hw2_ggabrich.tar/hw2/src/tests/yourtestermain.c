

// Tests toMorse with specified instream.
int testToMorse(FILE *instream) {
	char **result;
	return toMorse(instream, result);
}

int testCreateKey(char* keyphrase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ", char* key) {
	createKey(keyphrase, key);
} 

char testMorseToKey(char** msg, char* key) {
	return morseToKey(*msg, key);
}


