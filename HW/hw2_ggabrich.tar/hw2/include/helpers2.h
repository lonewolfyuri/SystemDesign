// Declare all helper functions for hw1 in this file

// given a character * cur, converts a lowercase to 
// uppercase, otherwise returns current char.
char * toUpper(char * cur);

// compares the first three chars of msg to each pattern in fmc.
int strcomp(char *msg, char *fmc, int len, int fmcLen);

// copies from src to dest until null terminator, and adds an 'x' to end.
// returns a number incremenet to null terminator in dest after the 'x'.
int strcopy(char *dest, char *src);

int strcomp2(char *msg, char **morseTable, int len);

int keyToMorse(char *cypher, char *key);

