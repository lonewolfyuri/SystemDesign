#ifndef HW3P3_H
#define HW3P3_H

#include "hw3_p2.h"

/*
 * Refer to the hw doc for description and details of this function
 */
IPV4_validation validateIPV4List(List_t* packets);

#endif
