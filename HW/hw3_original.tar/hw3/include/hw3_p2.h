#ifndef HW3P2_H
#define HW3P2_H

#include "packets.h"

/*
 * Refer to the hw doc for description and details of this function
 */
uint16_t verifyIPV4Checksum(IPV4_header* header);

#endif
