#include "hw3_p3.h"

IPV4_validation validateIPV4List(List_t* packets) {
    IPV4_validation valid;
    //Insert Code Here
    return valid;
}
