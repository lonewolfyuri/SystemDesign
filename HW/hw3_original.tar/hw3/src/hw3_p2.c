#include "hw3_p2.h"

uint16_t verifyIPV4Checksum(IPV4_header* header) {
    //Insert Code Here
    return 2;
}
